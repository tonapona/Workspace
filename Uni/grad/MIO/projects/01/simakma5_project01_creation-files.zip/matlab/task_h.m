clear
close all
clc

% task h
freqList = linspace(0.1, 20, 100)*1e9; % vector of frequencies
f0 = 10e9; % design frequency
% substrate 2
substrate = {'EpsilonR', 2.2, 'Height', 7*0.127e-3, 'LossTangent', 0.0009, ...
   'Thickness', 17e-6, 'SigmaCond', 5.88e7}; % definition of the substrate
% width of microstrip line with 50 Ohm impedance
w = microstripW(substrate, f0, 50, 0.1, 0.1e-3, 10e-3, 1e-6);
% create single object representing the microstrip line
microstrip = txlineMicrostrip(substrate{:}, 'Width', w);
% get its char. impedance and effective permittivity at all frequencies
[Z2, epsEff2] = getZ0(microstrip, freqList);

% substrate 4
substrate = {'EpsilonR', 10.2, 'Height', 0.635e-3, 'LossTangent', 0.0023, ...
   'Thickness', 17e-6, 'SigmaCond', 5.88e7}; % definition of the substrate
% width of microstrip line with 50 Ohm impedance
w = microstripW(substrate, f0, 50, 0.1, 0.1e-3, 10e-3, 1e-6);
% create single object representing the microstrip line
microstrip = txlineMicrostrip(substrate{:}, 'Width', w);
% get its char. impedance and effective permittivity at all frequencies
[Z4, epsEff4] = getZ0(microstrip, freqList);

figure
plot(freqList/1e9, Z2, freqList/1e9, Z4)
xlabel('f (GHz)')
ylabel('Z (\Omega)')
legend('Substrate 2', 'Substrate 4')

figure
plot(freqList/1e9, epsEff2, freqList/1e9, epsEff4)
xlabel('f (GHz)')
ylabel('\epsilon_{eff} (-)')
legend('Substrate 2', 'Substrate 4')